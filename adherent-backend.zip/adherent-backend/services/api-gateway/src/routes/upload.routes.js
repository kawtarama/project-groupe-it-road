const express = require('express');
const { uploadMiddleware, uploadFile } = require('../controllers/upload.controller');
const { authMiddleware } = require('../middlewares/auth.middleware');

const router = express.Router();

router.post('/upload', authMiddleware, uploadMiddleware, uploadFile);

module.exports = router;
