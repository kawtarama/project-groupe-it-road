const multer = require('multer');
const path = require('path');
const db = require('../db');

const storage = multer.diskStorage({
  destination: './uploads',
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

exports.uploadMiddleware = upload.single('file');

exports.uploadFile = async (req, res) => {
  const userId = req.user.id;
  const file = req.file;

  if (!file) return res.status(400).json({ error: 'Aucun fichier reçu' });

  const fileUrl = `/uploads/${file.filename}`;
  const name = file.originalname;

  const [doc] = await db('documents')
    .insert({ name, file_url: fileUrl, adherant_id: userId })
    .returning('*');

  res.status(201).json(doc);
};
